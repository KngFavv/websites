<?php 
	$conn = mysqli_connect('localhost','root','','recipe') or die('connection failed');

?>