<?php 
	$conn = mysqli_connect('localhost','root','','musiconline') or die('connection failed');

?>